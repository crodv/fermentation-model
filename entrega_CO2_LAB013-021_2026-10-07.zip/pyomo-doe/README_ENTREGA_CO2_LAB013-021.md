# Entrega CO2 y temperatura — LAB013–021

Esta es una entrega incremental para una copia existente del proyecto. Contiene siete análisis principales (SOURCE + EXECUTED cuando existen), un notebook de apoyo, los datos nuevos completos de LAB013–021, módulos existentes, parámetros/resultados congelados y documentación. No contiene los notebooks históricos ya compartidos de la imagen ni vuelve a enviar los datos originales anteriores a LAB013.

## Integración y lectura

1. Descomprimir. Se conserva la carpeta `pyomo-doe/fermentation_model/`.
2. Integrar su contenido en una copia del repositorio existente, conservando las rutas. Guardar una copia previa de los archivos que se vayan a reemplazar.
3. Leer primero `fermentation_model/laboratory_2026/notebooks/co2_reformulation/03_co2_reformulation_summary_v2.pdf`. La versión original también está incluida; v2 conserva además las comparaciones históricas.
4. Revisar los EXECUTED para consultar resultados sin recalcular. SOURCE es la copia para ejecutar; LAB016–018 tiene un único notebook con salidas incluidas. No ejecutar los generadores de notebooks desde los módulos `.py` para esta entrega.

## Orden de los análisis principales

Todos están bajo `fermentation_model/laboratory_2026/notebooks/`:

1. `theta_full_vs_incomplete_defaults_natural_review.ipynb`: procedencia de theta y comparación cinética; incluye LAB013–015.
2. `co2_solubility_o2_cross_matrix_2026_full_theta_no_lab010.ipynb`: recalibración de la capa CO2, señales reparadas y LAB013–015.
3. `lab016_018_natural_must_holdout.ipynb`: evaluación de LAB016–018 y antecedente del transitorio antiguo.
4. `holdouts/lab019_021_theta_full_holdout.ipynb`: predicciones de LAB019–021 con parámetros previos congelados.
5. `diagnostics/lab019_021_co2_onset_effective_model_test.ipynb`: ajuste ampliado de la capa CO2 y del transitorio.
6. `co2_reformulation/02_nutrition_structure_comparison.source.ipynb`: comparación de estructuras, theta y capa CO2; simplificación de la ecuación.
7. `diagnostics/lab019_021_co2_temperature_shape_audit.ipynb`: respuesta térmica, química y biomasa.

Apoyo: `natural_must_initial_conditions_analysis.ipynb` es requerido por la auditoría de fuentes del análisis 2. Se incluye para conservar ese control de procedencia; no es un octavo análisis recomendado para empezar.

## Datos y dependencias

- `fermentation_model/data/mem2026/LAB013-015/`, `LAB016-018/` y `LAB019-021/`: todos los archivos actuales, sin recorte ni transformación; incluyen offline, Y15, Oculyze, CO2 y temperatura. Los backups globales de LAB019–021 se conservan íntegros, aunque su ventana registrada sea más extensa que esos lotes.
- `Tabla_CO2_disuelto_carbodoseur_long.csv`: conversión auxiliar usada por los notebooks.
- Módulos `.py`: copias de las implementaciones existentes que los notebooks importan; no son nuevos auxiliares de análisis.
- `results/`: tablas necesarias de calibraciones, comparadores, señales reparadas, parámetros, soportes y resultados. Se incluyen algunas entradas procesadas de lotes antiguos porque son dependencias de la comparación cross-matrix; sus datos originales no se vuelven a enviar.
- La referencia Zenteno se copia en `context/Zenteno_2010.pdf`, ruta que requiere la auditoría de theta. Proviene del archivo actual en `context/modeling/` si la ruta antigua no existe.
- Se excluyen entornos Python, caches, registros de ejecución y notebooks adicionales sin dependencia directa.

Para ejecutar se necesita la copia histórica que el destinatario ya posee: datos de `data/Laboratorio 2026/` (incluidos workbook natural y raw_data), datos sintéticos de los lotes 1/2 y `data/mem2026/LAB290226/` para la comparación final del notebook LAB016–018. Mantener una carpeta raíz llamada `pyomo-doe`: los notebooks la buscan por nombre.

Usar el entorno Conda `fermentation` con sus dependencias declaradas en `fermentation_model/environment.yml`; activar realmente el entorno antes de iniciar Jupyter. En Windows, conservar Library/bin de Conda antes de IDAES/bin. No se empaquetan Python ni los binarios del solver. Las recalibraciones y búsquedas térmicas pueden tardar; los resultados ya están en EXECUTED.

## Convenciones relevantes

- `theta_defaults` conserva once estimaciones y seis defaults. Notebooks antiguos todavía lo llaman `theta_incomplete_defaults` o `theta_antiguo`; no representan vectores adicionales.
- Notebook 02: activación con consumo predicho de 5 g/L de G+F **o** generación predicha de 2 g/L de etanol.
- Auditoría térmica: consumo predicho de 6 g/L de G+F **o** generación predicha de 2 g/L de etanol, respecto del inicio simulado, con capa CO2 antigua y ecuación simplificada.
- Las comparaciones térmicas son diagnósticas; la preferencia de theta según el perfil térmico sigue siendo una hipótesis. Los lotes ya explorados no constituyen una validación independiente nueva.

## Integridad

`MANIFEST_CO2_LAB013-021.json` lista los archivos del proyecto, su procedencia, tamaño y SHA-256. Las copias son idénticas a los archivos actuales del repositorio; la entrega no reajusta ni reejecuta las optimizaciones. Se verifica la integridad ZIP y se realizan comprobaciones de importación y lectura de entradas, con el alcance documentado en el informe de verificación incluido.
